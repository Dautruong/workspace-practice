package com.spring.codeDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
