package com.spring.codeDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodeDemoApplication.class, args);
	}

}
